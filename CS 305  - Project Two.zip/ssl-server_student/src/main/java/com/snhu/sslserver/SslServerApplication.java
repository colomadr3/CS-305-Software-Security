package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{ 
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
    	String data = "Raphael Coloma";	// data string
    	String checkSum = null; // Checksum value
    	MessageDigest mdObject = MessageDigest.getInstance("SHA-256");	// Create and initialize MessageDigest object using SHA-256
    	
    	mdObject.update(data.getBytes()); // pass data string variable to messageDigest
    	byte[] digest = mdObject.digest(); // generate byte type hash value
    	checkSum = this.bytesToHex(digest); // pass hash value bytestoHex function   
    	
    	// return information to localhost:8443
        return "<p>Data: " + data + "<br>SHA-256 : " + checkSum + "</p>";
    }

   // bytesToHex function to convert hash value to hex
   public String bytesToHex(byte[] bytes) {
       StringBuilder hexString = new StringBuilder(2 * bytes.length);
       // loop through byte array
       for (int i = 0; i < bytes.length; i++) {
           String hex = Integer.toHexString(0xff & bytes[i]);
           if (hex.length() == 1) {
        	   hexString.append('0');	// append elements
           }
           hexString.append(hex);
       }
       return hexString.toString();		// return hexadecimal string
   }
}
